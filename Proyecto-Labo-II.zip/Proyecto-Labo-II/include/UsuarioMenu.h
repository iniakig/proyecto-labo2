#ifndef USUARIOMENU_H
#define USUARIOMENU_H

#include "UsuarioManager.h"

class UsuarioMenu
{
private:
    UsuarioManager _usuarioManager;

public:
    void mostrar();
};

#endif // USUARIOMENU_H
