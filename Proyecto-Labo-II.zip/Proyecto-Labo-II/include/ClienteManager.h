#ifndef CLIENTEMANAGER_H
#define CLIENTEMANAGER_H


class ClienteManager
{
    public:
        ClienteManager();
        virtual ~ClienteManager();

    protected:

    private:
};

#endif // CLIENTEMANAGER_H
