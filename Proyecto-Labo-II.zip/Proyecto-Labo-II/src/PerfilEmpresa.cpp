#include "PerfilEmpresa.h"

PerfilEmpresa::PerfilEmpresa()
{

}
